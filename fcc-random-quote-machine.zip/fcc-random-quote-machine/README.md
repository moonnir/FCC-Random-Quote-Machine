# FCC : Random Quote Machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/moonnir/pen/xxYYXOZ](https://codepen.io/moonnir/pen/xxYYXOZ).

